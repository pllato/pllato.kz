/* SPDX-License-Identifier: GPL-3.0-or-later
   Small DWG-only bridge. Each browser worker owns one document. */
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdio.h>
#include "dwg.h"
#include "dwg_api.h"
#include "bits.h"
#ifdef __EMSCRIPTEN__
#include <emscripten/emscripten.h>
#define API EMSCRIPTEN_KEEPALIVE
#else
#define API
#endif

static Dwg_Data drawing;
static int loaded;

API void pllato_close (void)
{
  dwg_free (&drawing);
  memset (&drawing, 0, sizeof (drawing));
  loaded = 0;
}

API int pllato_open (const char *path)
{
  int error;
  pllato_close ();
  error = dwg_read_file (path, &drawing);
  if (error >= DWG_ERR_CRITICAL)
    { pllato_close (); return error; }
  loaded = 1;
  for (unsigned i = 0; i < drawing.num_objects; i++) {
    Dwg_Object *o = &drawing.object[i];
    if (o->supertype == DWG_SUPERTYPE_ENTITY && o->tio.entity->color.flag == 192
        && !o->tio.entity->color.handle) {
      o->tio.entity->color.flag = 0;
      o->tio.entity->color.raw = o->tio.entity->color.index;
    }
  }
  /* Recover only the provable ENC-C0 shift: color -> LAYER, layer ->
     BLOCK_HEADER, missing INSERT block. Keep valid DBCOLOR refs untouched. */
  for (unsigned i = 0; i < drawing.num_objects; i++) {
    Dwg_Object *o = &drawing.object[i];
    if (o->fixedtype != DWG_TYPE_INSERT) continue;
    Dwg_Object_Entity *e = o->tio.entity;
    Dwg_Entity_INSERT *ins = e->tio.INSERT;
    if (e->color.flag != 192 || !e->color.handle || !e->layer
        || (ins->block_header && ins->block_header->absolute_ref)) continue;
    Dwg_Object *layer = dwg_ref_object (&drawing, e->color.handle);
    Dwg_Object *block = dwg_ref_object (&drawing, e->layer);
    if (!layer || layer->fixedtype != DWG_TYPE_LAYER
        || !block || block->fixedtype != DWG_TYPE_BLOCK_HEADER) continue;
    ins->block_header = e->layer;
    e->layer = e->color.handle;
    e->color.handle = NULL;
    e->color.flag = 0;
    e->color.raw = e->color.index;
  }
  return error;
}

static Dwg_Object *entity (const char *handle)
{
  char *end;
  unsigned long long h;
  Dwg_Object *obj;
  if (!loaded || !handle || !*handle) return NULL;
  h = strtoull (handle, &end, 16);
  if (*end || !h) return NULL;
  obj = dwg_resolve_handle (&drawing, h);
  if (!obj || obj->supertype != DWG_SUPERTYPE_ENTITY) return NULL;
  return obj;
}

API int pllato_move (const char *handle, double dx, double dy)
{
  Dwg_Object *obj = entity (handle);
  BITCODE_3BD extrusion = { 0, 0, 1 };
  void *tio;
  if (!obj || !isfinite (dx) || !isfinite (dy)) return 1;
  tio = obj->tio.entity->tio.LINE;
  if (!(obj->fixedtype == DWG_TYPE_LWPOLYLINE
        && !(obj->tio.entity->tio.LWPOLYLINE->flag & 1))
      && dwg_dynapi_entity_value (tio, obj->name, "extrusion", &extrusion, NULL)
      && (extrusion.x || extrusion.y || extrusion.z != 1)) return 2;
#define SHIFT(p) do { \
  if (!isfinite ((p).x + dx) || !isfinite ((p).y + dy)) return 5; \
  (p).x += dx; (p).y += dy; \
} while (0)
  switch (obj->fixedtype)
    {
    case DWG_TYPE_LINE:
      SHIFT (obj->tio.entity->tio.LINE->start);
      SHIFT (obj->tio.entity->tio.LINE->end); break;
    case DWG_TYPE_TEXT:
      SHIFT (obj->tio.entity->tio.TEXT->ins_pt);
      SHIFT (obj->tio.entity->tio.TEXT->alignment_pt); break;
    case DWG_TYPE_MTEXT: SHIFT (obj->tio.entity->tio.MTEXT->ins_pt); break;
    case DWG_TYPE_INSERT:
      /* Attributes are independent entities: do not detach them from a block. */
      if (obj->tio.entity->tio.INSERT->has_attribs) return 3;
      SHIFT (obj->tio.entity->tio.INSERT->ins_pt); break;
    case DWG_TYPE_CIRCLE: SHIFT (obj->tio.entity->tio.CIRCLE->center); break;
    case DWG_TYPE_ARC: SHIFT (obj->tio.entity->tio.ARC->center); break;
    case DWG_TYPE_LWPOLYLINE:
      for (unsigned i = 0; i < obj->tio.entity->tio.LWPOLYLINE->num_points; i++)
        SHIFT (obj->tio.entity->tio.LWPOLYLINE->points[i]);
      break;
    default: return 4;
    }
#undef SHIFT
  return 0;
}

API int pllato_text (const char *handle, const char *utf8)
{
  Dwg_Object *obj = entity (handle);
  BITCODE_T replacement;
  if (!obj || obj->fixedtype != DWG_TYPE_TEXT || !utf8) return 1;
  replacement = dwg_add_u8_input (&drawing, utf8);
  if (!replacement) return 2;
  free (obj->tio.entity->tio.TEXT->text_value);
  obj->tio.entity->tio.TEXT->text_value = replacement;
  return 0;
}

API int pllato_save (const char *path)
{
  Dwg_Data check = { 0 };
  int error;
  if (!loaded) return DWG_ERR_INVALIDDWG;
  /* R2007 is implicitly upgraded upstream; disallow implicit conversion. */
  if (drawing.header.version == R_2007
      || drawing.header.version != drawing.header.from_version)
    return DWG_ERR_NOTYETSUPPORTED | DWG_ERR_INVALIDDWG;
  error = dwg_write_file (path, &drawing);
  if (error >= DWG_ERR_CRITICAL) return error;
  error = dwg_read_file (path, &check);
  if (error < DWG_ERR_CRITICAL && check.num_objects != drawing.num_objects)
    { fprintf(stderr,"VERIFY count %u -> %u\n",drawing.num_objects,check.num_objects); error |= DWG_ERR_INVALIDDWG; }
  if (error < DWG_ERR_CRITICAL)
    for (unsigned i = 0; i < drawing.num_objects; i++)
      {
        Dwg_Object *a = &drawing.object[i];
        Dwg_Object *b = dwg_resolve_handle (&check, a->handle.value);
        if (!b || a->fixedtype != b->fixedtype)
          { fprintf(stderr,"VERIFY type %llx\n",(unsigned long long)a->handle.value); error |= DWG_ERR_INVALIDDWG; break; }
        if (a->fixedtype == DWG_TYPE_INSERT) {
          Dwg_Object_Ref *ar = a->tio.entity->tio.INSERT->block_header;
          Dwg_Object_Ref *br = b->tio.entity->tio.INSERT->block_header;
          if ((ar ? ar->absolute_ref : 0) != (br ? br->absolute_ref : 0))
            { fprintf(stderr,"VERIFY block %llx: %llx -> %llx\n",(unsigned long long)a->handle.value,(unsigned long long)(ar?ar->absolute_ref:0),(unsigned long long)(br?br->absolute_ref:0)); error |= DWG_ERR_INVALIDDWG; break; }
        }
      }
  dwg_free (&check);
  return error;
}

API unsigned pllato_count (void) { return loaded ? drawing.num_objects : 0; }

/* New geometry is appended to model space, never substituted for the source. */
static void new_entity_style (Dwg_Object_Entity *e)
{
  BITCODE_H layer=dwg_find_tablehandle(&drawing,"0","LAYER");
  if(layer)e->layer=dwg_add_handleref(&drawing,5,layer->absolute_ref,NULL);
  e->color.index=7;e->color.flag=0;e->color.raw=7;
}
API int pllato_add_line (double x1, double y1, double x2, double y2)
{
  Dwg_Object *model;
  Dwg_Entity_LINE *line;
  dwg_point_3d a = {x1,y1,0}, b = {x2,y2,0};
  if (!loaded || !isfinite(x1) || !isfinite(y1) || !isfinite(x2) || !isfinite(y2)) return 1;
  model = dwg_model_space_object (&drawing);
  if (!model) return 2;
  line=dwg_add_LINE (model->tio.object->tio.BLOCK_HEADER,&a,&b);
  if(!line)return 3;
  new_entity_style(line->parent);return 0;
}

API int pllato_add_text (const char *text, double x, double y, double height, double angle)
{
  Dwg_Object *model;
  Dwg_Entity_TEXT *t;
  dwg_point_3d p = {x,y,0};
  if (!loaded || !text || strlen(text)>8000 || !isfinite(x) || !isfinite(y)
      || !isfinite(height) || height<=0 || !isfinite(angle)) return 1;
  model = dwg_model_space_object (&drawing);
  if (!model) return 2;
  t = dwg_add_TEXT (model->tio.object->tio.BLOCK_HEADER,text,&p,height);
  if (!t) return 3;
  new_entity_style(t->parent);
  BITCODE_H style=dwg_find_tablehandle(&drawing,"Standard","STYLE");
  if(style)t->style=dwg_add_handleref(&drawing,5,style->absolute_ref,NULL);
  t->rotation=angle;
  return 0;
}

API int pllato_add_polyline (const double *xy, unsigned count, int closed)
{
  Dwg_Object *model;
  Dwg_Entity_LWPOLYLINE *p;
  if (!loaded || !xy || count<2 || count>100000) return 1;
  for(unsigned i=0;i<count*2;i++) if(!isfinite(xy[i])) return 1;
  model = dwg_model_space_object (&drawing);
  if (!model) return 2;
  p=dwg_add_LWPOLYLINE(model->tio.object->tio.BLOCK_HEADER,count,(const dwg_point_2d *)xy);
  if(!p) return 3;
  new_entity_style(p->parent);
  if(closed)p->flag|=512;
  return 0;
}
