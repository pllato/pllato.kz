/* GPL-3.0-or-later. Synthetic regression, no customer drawings required. */
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "dwg.h"
#include "dwg_api.h"
#include "bits.h"

int
main (int argc, char **argv)
{
  Dwg_Data *dwg;
  Dwg_Data reread = { 0 };
  Dwg_Object *model;
  Dwg_Entity_MTEXT *text;
  Dwg_Entity_LINE *line;
  dwg_point_3d pt = { 3.0, 4.0, 0.0 };
  char content[7001];
  unsigned count = 0;
  int error;
  assert (argc == 2 && access (argv[1], F_OK) != 0);
  for (unsigned i = 0; i < sizeof (content) - 1; i++)
    content[i] = 'A' + i % 26;
  content[sizeof (content) - 1] = 0;
  dwg = dwg_new_Document (R_2018, 0, 0);
  assert (dwg);
  for (unsigned i = 0; i < 200; i++)
    {
      char name[128];
      snprintf (name, sizeof (name), "PLLATO_CLASS_%03u_LONG_STRING_STREAM", i);
      assert (dwg_add_class (dwg, name, name, "PLLATO_REGRESSION", false) >= 500);
    }
  model = dwg_model_space_object (dwg);
  assert (model && model->tio.object);
  text = dwg_add_MTEXT (model->tio.object->tio.BLOCK_HEADER, &pt, 100.0,
                        content);
  assert (text);
  model = dwg_model_space_object (dwg);
  line = dwg_add_LINE (model->tio.object->tio.BLOCK_HEADER, &pt, &pt);
  assert (line);
  line->parent->color.flag = 0x20;
  line->parent->color.alpha_raw = 0xc2cacbc5u;
  line->parent->color.alpha_type = 0xc2;
  line->parent->color.alpha = 0xc5;
  error = dwg_write_file (argv[1], dwg);
  assert (error < DWG_ERR_CRITICAL);
  error = dwg_read_file (argv[1], &reread);
  assert (error < DWG_ERR_CRITICAL);
  assert (reread.num_classes == dwg->num_classes);
  for (unsigned i = 0; i < dwg->num_classes; i++)
    assert (!strcmp (dwg->dwg_class[i].dxfname,
                     reread.dwg_class[i].dxfname));
  for (unsigned i = 0; i < reread.num_objects; i++)
    if (reread.object[i].fixedtype == DWG_TYPE_LINE)
      assert (reread.object[i].tio.entity->color.alpha_raw == 0xc2cacbc5u);
    else if (reread.object[i].fixedtype == DWG_TYPE_MTEXT)
      {
        char *actual = bit_convert_TU (
            (BITCODE_TU)reread.object[i].tio.entity->tio.MTEXT->text);
        assert (actual && !strcmp (actual, content));
        free (actual);
        count++;
      }
  assert (count == 1);
  dwg_free (&reread);
  dwg_free (dwg);
  free (dwg);
  puts ("PASS: long class stream and 7000-character MTEXT survive R2018 write/read");
  return 0;
}
