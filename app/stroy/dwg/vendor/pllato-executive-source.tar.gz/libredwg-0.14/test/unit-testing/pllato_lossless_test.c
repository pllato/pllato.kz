/* GPL-3.0-or-later. Reject version conversion before unknown objects mutate. */
#include <assert.h>
#include <string.h>
#include <unistd.h>
#include "dwg.h"

int
main (int argc, char **argv)
{
  Dwg_Data dwg;
  Dwg_Object obj;
  int error;
  assert (argc == 2);
  assert (access (argv[1], F_OK) != 0);
  memset (&dwg, 0, sizeof (dwg));
  memset (&obj, 0, sizeof (obj));
  dwg.header.from_version = R_2018;
  dwg.header.version = R_2000;
  dwg.num_objects = 1;
  dwg.object = &obj;
  obj.fixedtype = DWG_TYPE_UNKNOWN_OBJ;
  error = dwg_write_file (argv[1], &dwg);
  assert (error >= DWG_ERR_CRITICAL);
  assert (obj.fixedtype == DWG_TYPE_UNKNOWN_OBJ);
  assert (access (argv[1], F_OK) != 0);
  obj.fixedtype = DWG_TYPE_UNKNOWN_ENT;
  error = dwg_write_file (argv[1], &dwg);
  assert (error >= DWG_ERR_CRITICAL);
  assert (obj.fixedtype == DWG_TYPE_UNKNOWN_ENT);
  assert (access (argv[1], F_OK) != 0);
  return 0;
}
