#include <stdio.h>
#include <assert.h>
#include "dwg.h"
int main(int argc,char **argv){
 Dwg_Data d={0},r={0};Dwg_Object *o;
 assert(argc==3);
 assert(dwg_read_file(argv[1],&d)<DWG_ERR_CRITICAL);
 o=dwg_resolve_handle(&d,8414128);assert(o);
 printf("before %08x\n",o->tio.entity->color.alpha_raw);
 assert(dwg_write_file(argv[2],&d)<DWG_ERR_CRITICAL);
 printf("after encode %08x\n",o->tio.entity->color.alpha_raw);
 assert(dwg_read_file(argv[2],&r)<DWG_ERR_CRITICAL);
 o=dwg_resolve_handle(&r,8414128);assert(o);
 printf("after decode %08x\n",o->tio.entity->color.alpha_raw);
 dwg_free(&d);dwg_free(&r);return 0;
}
