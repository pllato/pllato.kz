/* SPDX-License-Identifier: GPL-3.0-or-later */
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "dwg.h"
#include "bits.h"
int pllato_open (const char *);
int pllato_move (const char *, double, double);
int pllato_text (const char *, const char *);
int pllato_save (const char *);
void pllato_close (void);
int main (int argc, char **argv)
{
  Dwg_Data original = { 0 }, result = { 0 };
  Dwg_Object *line = NULL, *text = NULL, *moved, *edited;
  char lh[32], th[32];
  const char *label = "Проверка DWG · 123";
  char *actual;
  assert (argc == 3 && access (argv[2], F_OK) != 0);
  assert (dwg_read_file (argv[1], &original) < DWG_ERR_CRITICAL);
  for (unsigned i = 0; i < original.num_objects; i++)
    {
      Dwg_Object *o = &original.object[i];
      if (!line && o->fixedtype == DWG_TYPE_LINE
          && !o->tio.entity->tio.LINE->extrusion.x
          && !o->tio.entity->tio.LINE->extrusion.y
          && o->tio.entity->tio.LINE->extrusion.z == 1) line = o;
      if (!text && o->fixedtype == DWG_TYPE_TEXT) text = o;
    }
  assert (line && text);
  snprintf (lh, sizeof (lh), "%llX", (unsigned long long)line->handle.value);
  snprintf (th, sizeof (th), "%llX", (unsigned long long)text->handle.value);
  assert (pllato_open (argv[1]) < DWG_ERR_CRITICAL);
  assert (pllato_move ("not-a-handle", 1, 2) != 0);
  assert (!pllato_move (lh, 12.5, -7.75));
  assert (!pllato_text (th, label));
  assert (pllato_save (argv[2]) < DWG_ERR_CRITICAL);
  assert (dwg_read_file (argv[2], &result) < DWG_ERR_CRITICAL);
  moved = dwg_resolve_handle (&result, line->handle.value);
  edited = dwg_resolve_handle (&result, text->handle.value);
  assert (moved && edited);
  assert (moved->tio.entity->tio.LINE->start.x
          == line->tio.entity->tio.LINE->start.x + 12.5);
  assert (moved->tio.entity->tio.LINE->end.y
          == line->tio.entity->tio.LINE->end.y - 7.75);
  actual = bit_convert_TU ((BITCODE_TU)edited->tio.entity->tio.TEXT->text_value);
  assert (actual && !strcmp (actual, label));
  free (actual);
  pllato_close ();
  dwg_free (&original);
  dwg_free (&result);
  puts ("PASS: direct DWG move and Cyrillic TEXT edit survive save/read");
  return 0;
}
