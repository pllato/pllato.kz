/* src/config.h.  Generated from config.h.in by configure.  */
/* src/config.h.in.  Generated from configure.ac by autoheader.  */

#ifndef CONFIG_H
#define CONFIG_H 1

/* Define if building universal (internal helper macro) */
/* #undef AC_APPLE_UNIVERSAL_BUILD */

/* Defined to <strings.h> or <string.h> if strcasecmp is found */
#define AX_STRCASECMP_HEADER <strings.h>

/* Define to 1 if using 'alloca.c'. */
/* #undef C_ALLOCA */

/* Define to enable unstable classes. */
/* #undef DEBUG_CLASSES */

/* Define to disable bindings. */
#define DISABLE_BINDINGS 1

/* Define to disable DXF, JSON and other in/out modules. */
/* #undef DISABLE_DXF */

/* Define to disable JSON and GeoJSON in/out modules. */
/* #undef DISABLE_JSON */

/* Number of dxf after-comma places (default 16). */
#define DXF_PRECISION 16

/* Define to 1 if mimalloc-override.h should be used. */
/* #undef ENABLE_MIMALLOC */

/* Define to 1 if a shared library will be built */
/* #undef ENABLE_SHARED */

/* Number of geojson after-comma places (recommended 6 by RFC). */
#define GEOJSON_PRECISION 16

/* versions earlier than 301 will have no size_t */
#define GPERF_VERSION 300

/* Define if pointers to integers require aligned access */
/* #undef HAVE_ALIGNED_ACCESS_REQUIRED */

/* Define to 1 if you have 'alloca', as a function or macro. */
#define HAVE_ALLOCA 1

/* Define to 1 if <alloca.h> works. */
#define HAVE_ALLOCA_H 1

/* AddressSanitizer detected in CFLAGS or CC */
#define HAVE_ASAN 1

/* Define if __attribute__((visibility("default"))) is supported. */
#define HAVE_ATTRIBUTE_VISIBILITY_DEFAULT 1

/* Define to 1 if you have the 'basename' function. */
#define HAVE_BASENAME 1

/* Define to 1 if be64toh is available in <endian.h>. */
#define HAVE_BE64TOH 1

/* Define to 1 if you have the <byteorder.h> header file. */
/* #undef HAVE_BYTEORDER_H */

/* Define to 1 if you have the <byteswap.h> header file. */
#define HAVE_BYTESWAP_H 1

/* Defined to 1 when the compiler supports C11 */
#define HAVE_C11 1

/* Defined to 1 when the compiler supports C99, mostly (...) macros */
#define HAVE_C99 1

/* Define to 1 if you have the <ctype.h> header file. */
#define HAVE_CTYPE_H 1

/* Define to 1 if you have the <direct.h> header file. */
/* #undef HAVE_DIRECT_H */

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* Define to 1 if you have the <endian.h> header file. */
#define HAVE_ENDIAN_H 1

/* Define to 1 if you have the <float.h> header file. */
#define HAVE_FLOAT_H 1

/* Define to 1 if you have the 'floor' function. */
#define HAVE_FLOOR 1

/* Define to 1 if the system has the `aligned' function attribute */
#define HAVE_FUNC_ATTRIBUTE_ALIGNED 1

/* Define to 1 if the system has the `counted_by' function attribute */
#define HAVE_FUNC_ATTRIBUTE_COUNTED_BY 1

/* Define to 1 if the system has the `format' function attribute */
#define HAVE_FUNC_ATTRIBUTE_FORMAT 1

/* Define to 1 if the system has the `gnu_format' function attribute */
#define HAVE_FUNC_ATTRIBUTE_GNU_FORMAT 1

/* Define to 1 if the system has the `malloc' function attribute */
#define HAVE_FUNC_ATTRIBUTE_MALLOC 1

/* Define to 1 if the system has the `ms_format' function attribute */
/* #undef HAVE_FUNC_ATTRIBUTE_MS_FORMAT */

/* Define to 1 if the system has the `noreturn' function attribute */
#define HAVE_FUNC_ATTRIBUTE_NORETURN 1

/* Define to 1 if the system has the `returns_nonnull' function attribute */
#define HAVE_FUNC_ATTRIBUTE_RETURNS_NONNULL 1

/* Define to 1 if you have the <getopt.h> header file. */
#define HAVE_GETOPT_H 1

/* Define to 1 if you have the 'getopt_long' function. */
#define HAVE_GETOPT_LONG 1

/* Define to 1 if you have the 'gettimeofday' function. */
#define HAVE_GETTIMEOFDAY 1

/* Define to 1 if you have the 'gmtime_r' function. */
#define HAVE_GMTIME_R 1

/* macOS 12.6.5 lies about its gperf version, using size_t as 3.0 */
/* #undef HAVE_GPERF_SIZE_T */

/* Define to 1 if htobe16 is available in <endian.h>. */
#define HAVE_HTOBE16 1

/* Define to 1 if htobe32 is available in <endian.h>. */
#define HAVE_HTOBE32 1

/* Define to 1 if htobe64 is available in <endian.h>. */
#define HAVE_HTOBE64 1

/* Define to 1 if htole32 is available in <endian.h>. */
#define HAVE_HTOLE32 1

/* Define to 1 if htole64 is available in <endian.h>. */
#define HAVE_HTOLE64 1

/* Define if you have the iconv() function. */
#define HAVE_ICONV 1

/* Define to 1 if you have the <iconv.h> header file. */
#define HAVE_ICONV_H 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if le16toh is available in <endian.h>. */
#define HAVE_LE16TOH 1

/* Define to 1 if le32toh is available in <endian.h>. */
#define HAVE_LE32TOH 1

/* Define to 1 if le64toh is available in <endian.h>. */
#define HAVE_LE64TOH 1

/* Define to 1 if you have the <libgen.h> header file. */
#define HAVE_LIBGEN_H 1

/* Define to 1 if you have the 'm' library (-lm). */
#define HAVE_LIBM 1

/* Define to 1 if you have the <libps/pslib.h> header file. */
/* #undef HAVE_LIBPS_PSLIB_H */

/* Define to 1 if you have the <limits.h> header file. */
#define HAVE_LIMITS_H 1

/* Define to 1 if you have the <machine/endian.h> header file. */
/* #undef HAVE_MACHINE_ENDIAN_H */

/* Define to 1 if your system has a GNU libc compatible 'malloc' function, and
   to 0 otherwise. */
#define HAVE_MALLOC 1

/* Define to 1 if you have the <malloc.h> header file. */
#define HAVE_MALLOC_H 1

/* Define to 1 if you have the 'memchr' function. */
#define HAVE_MEMCHR 1

/* Define to 1 if you have the 'memmem' function. */
#define HAVE_MEMMEM 1

/* Define to 1 if you have the 'memmove' function. */
#define HAVE_MEMMOVE 1

/* Define to 1 if you have the <mimalloc-override.h> header file. */
#define HAVE_MIMALLOC_OVERRIDE_H 1

/* Define to 1 if -lpcre2-16 is used also */
/* #undef HAVE_PCRE2_16 */

/* Define to 1 if you have the <pcre2.h> header file. */
/* #undef HAVE_PCRE2_H */

/* If available, contains the Python version number currently in use. */
/* #undef HAVE_PYTHON */

/* Define to 1 if your system has a GNU libc compatible 'realloc' function,
   and to 0 otherwise. */
#define HAVE_REALLOC 1

/* Define to 1 if you have the 'scandir' function. */
#define HAVE_SCANDIR 1

/* Define to 1 if you have the 'setenv' function. */
#define HAVE_SETENV 1

/* Define to 1 if you have the 'sincos' function. */
#define HAVE_SINCOS 1

/* Define to 1 if you have the 'sqrt' function. */
#define HAVE_SQRT 1

/* Define to 1 if you have the 'sscanf_s' function. */
/* #undef HAVE_SSCANF_S */

/* Define to 1 if 'stat' has the bug that it succeeds when given the
   zero-length file name argument. */
/* #undef HAVE_STAT_EMPTY_STRING_BUG */

/* Define to 1 if you have the <stddef.h> header file. */
#define HAVE_STDDEF_H 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdio.h> header file. */
#define HAVE_STDIO_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the 'strcasecmp' function. */
#define HAVE_STRCASECMP 1

/* Define to 1 if you have the 'strcasestr' function. */
#define HAVE_STRCASESTR 1

/* Define to 1 if you have the 'strchr' function. */
#define HAVE_STRCHR 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the 'strnlen' function. */
#define HAVE_STRNLEN 1

/* Define to 1 if you have the 'strrchr' function. */
#define HAVE_STRRCHR 1

/* Define to 1 if you have the 'strstr' function. */
#define HAVE_STRSTR 1

/* Define to 1 if you have the 'strtol' function. */
#define HAVE_STRTOL 1

/* Define to 1 if you have the 'strtoll' function. */
#define HAVE_STRTOLL 1

/* Define to 1 if you have the 'strtoul' function. */
#define HAVE_STRTOUL 1

/* Define to 1 if you have the 'strtoull' function. */
#define HAVE_STRTOULL 1

/* Define to 1 if you have the <sys/byteorder.h> header file. */
/* #undef HAVE_SYS_BYTEORDER_H */

/* Define to 1 if you have the <sys/endian.h> header file. */
/* #undef HAVE_SYS_ENDIAN_H */

/* Define to 1 if you have the <sys/param.h> header file. */
#define HAVE_SYS_PARAM_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/time.h> header file. */
#define HAVE_SYS_TIME_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to 1 if you have the <valgrind/valgrind.h> header file. */
/* #undef HAVE_VALGRIND_VALGRIND_H */

/* Define to 1 if you have the <wchar.h> header file. */
#define HAVE_WCHAR_H 1

/* Define to 1 if you have the 'wcscmp' function. */
#define HAVE_WCSCMP 1

/* Define to 1 if you have the 'wcscpy' function. */
#define HAVE_WCSCPY 1

/* Define to 1 if you have the 'wcslen' function. */
#define HAVE_WCSLEN 1

/* Define to 1 if you have the 'wcsnlen' function. */
#define HAVE_WCSNLEN 1

/* Define to 1 if you have the 'wcsstr' function. */
#define HAVE_WCSSTR 1

/* Define to 1 if you have the <wctype.h> header file. */
#define HAVE_WCTYPE_H 1

/* If -Werror is enabled. */
/* #undef HAVE_WERROR */

/* Define if -Wformat-y2k is supported. */
#define HAVE_WFORMAT_Y2K 1

/* Define to 1 if you have the <winsock2.h> header file. */
/* #undef HAVE_WINSOCK2_H */

/* Define to 1 if the system has the type '_Bool'. */
#define HAVE__BOOL 1

/* Define as const if the declaration of iconv() needs const. */
#define ICONV_CONST 

/* Define to 1 if this is a release, skipping unstable DWG features, unknown
   DWG versions and objects. */
#define IS_RELEASE 1

/* Defined in configure.ac to the libtool version-info of the shared lib. */
#define LIBREDWG_SO_VERSION "0:14:0"

/* Define to 1 if 'lstat' dereferences a symlink specified with a trailing
   slash. */
#define LSTAT_FOLLOWS_SLASHED_SYMLINK 1

/* Define to the sub-directory where libtool stores uninstalled libraries. */
#define LT_OBJDIR ".libs/"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "libredwg@gnu.org"

/* Define to the full name of this package. */
#define PACKAGE_NAME "LibreDWG"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "LibreDWG 0.14"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "libredwg"

/* Define to the home page for this package. */
#define PACKAGE_URL "https://savannah.gnu.org/projects/libredwg/"

/* Define to the version of this package. */
#define PACKAGE_VERSION "0.14"

/* Define to the printf() modifier to use with size_t. */
#define PRI_SIZE_T_MODIFIER "z"

/* The size of 'size_t', as computed by sizeof. */
#define SIZEOF_SIZE_T 4

/* The number of bytes in type wchar_t */
#define SIZEOF_WCHAR_T 4

/* If using the C implementation of alloca, define if you know the
   direction of stack growth for your system; otherwise it will be
   automatically deduced at runtime.
	STACK_DIRECTION > 0 => grows toward higher addresses
	STACK_DIRECTION < 0 => grows toward lower addresses
	STACK_DIRECTION = 0 => direction of growth unknown */
/* #undef STACK_DIRECTION */

/* Define to 1 if all of the C89 standard headers exist (not just the ones
   required in a freestanding environment). This macro is provided for
   backward compatibility; new code need not use it. */
#define STDC_HEADERS 1

/* Define to 1 to enable runtime tracing support. */
/* #undef USE_TRACING */

/* Undefine to disable write support. */
#define USE_WRITE 1

/* Define WORDS_BIGENDIAN to 1 if your processor stores words with the most
   significant byte first (like Motorola and SPARC, unlike Intel). */
#if defined AC_APPLE_UNIVERSAL_BUILD
# if defined __BIG_ENDIAN__
#  define WORDS_BIGENDIAN 1
# endif
#else
# ifndef WORDS_BIGENDIAN
/* #  undef WORDS_BIGENDIAN */
# endif
#endif

/* Needed for strdup */
#ifndef _POSIX_C_SOURCE
# define _POSIX_C_SOURCE 900000L
#endif

/* Define for Solaris 2.5.1 so the uint32_t typedef from <sys/synch.h>,
   <pthread.h>, or <semaphore.h> is not used. If the typedef were allowed, the
   #define below would cause a syntax error. */
/* #undef _UINT32_T */

/* Define for Solaris 2.5.1 so the uint64_t typedef from <sys/synch.h>,
   <pthread.h>, or <semaphore.h> is not used. If the typedef were allowed, the
   #define below would cause a syntax error. */
/* #undef _UINT64_T */

/* Needed for cygwin strdup */
/* #undef __XSI_VISIBLE */

/* Define to '__inline__' or '__inline' if that's what the C compiler
   calls it, or to nothing if 'inline' is not supported under any name.  */
#ifndef __cplusplus
/* #undef inline */
#endif

/* Define to the type of a signed integer type of width exactly 16 bits if
   such a type exists and the standard includes do not define it. */
/* #undef int16_t */

/* Define to the type of a signed integer type of width exactly 32 bits if
   such a type exists and the standard includes do not define it. */
/* #undef int32_t */

/* Define to the type of a signed integer type of width exactly 64 bits if
   such a type exists and the standard includes do not define it. */
/* #undef int64_t */

/* Define to rpl_malloc if the replacement function should be used. */
/* #undef malloc */

/* Define to rpl_realloc if the replacement function should be used. */
/* #undef realloc */

/* If restrict is broken with this C compiler */
#define restrict 

/* Define as 'unsigned int' if <stddef.h> doesn't define. */
/* #undef size_t */

/* Define to the type of an unsigned integer type of width exactly 16 bits if
   such a type exists and the standard includes do not define it. */
/* #undef uint16_t */

/* Define to the type of an unsigned integer type of width exactly 32 bits if
   such a type exists and the standard includes do not define it. */
/* #undef uint32_t */

/* Define to the type of an unsigned integer type of width exactly 64 bits if
   such a type exists and the standard includes do not define it. */
/* #undef uint64_t */

#endif /* CONFIG_H */
