# Pllato DWG writer — reproducible source build

0.11 authoring bridge: append LINE, TEXT (UTF-8) and LWPOLYLINE in model space. New entities use layer 0 and ACI 7; TEXT uses Standard if present. APIs validate finite coordinates. Original-object deletion and region cloning are not implemented.

0.9: correct the C0 indexed-color case in common_entity_data.spec (no phantom color handle), normalize it on open, and validate INSERT block references after write/read in addition to object counts/types/handles. Tested with the supplied apartment R2018 drawing; this does not guarantee all third-party DWG objects.

GPL-3.0-or-later. GNU LibreDWG 0.14 plus the included Pllato patches.
Toolchain used: Emscripten 6.0.10, Python 3.14, Node 26; no paid SDK.

Build in a fresh subdirectory with Emscripten activated:

```sh
mkdir build-web
cd build-web
emconfigure ../configure --disable-shared --disable-docs --disable-python --disable-bindings CFLAGS=-O1
make -C src -j2 libredwg.la
emcc ../pllato_web.c src/.libs/libredwg.a -I../include -I../src -Isrc -O1 -sMODULARIZE=1 -sEXPORT_ES6=1 -sENVIRONMENT=web,worker,node -sALLOW_MEMORY_GROWTH=1 -sINITIAL_MEMORY=67108864 -sMAXIMUM_MEMORY=4294967296 -sSTACK_SIZE=5242880 '-sEXPORTED_RUNTIME_METHODS=["ccall","FS"]' -o pllato-engine.mjs
```

Serve the generated `.mjs` and `.wasm` together. Every worker owns a single document.
The bridge exports open, move, TEXT edit, save, count, close. It never converts through DXF.
Saving keeps the input DWG version, writes a separate file and re-reads it to check object handles/types/count.
This is experimental software, not an assurance of complete AutoCAD compatibility.
R2007 implicit version upgrades are rejected. INSERTs with attributes cannot be moved.
The application must retain the original, show reader/writer limitations, and never replace failed output with an unedited original.

Tests added: string footer boundaries at all bit offsets; exact DD doubles; partial raw bits; synthetic long class names and 7000-character MTEXT; direct move/TEXT write/read.
Run the native tests from an out-of-tree configure/make build. `bits_test` is the upstream unit executable.
The standalone `pllato_strings_roundtrip_test.c` and `pllato_web_test.c` link with libredwg and libm; include directories are `include`, `src`, and the build's `src`.
